const Doctor = require("../models/doctorModel");
const User = require("../models/userModel");
const Notification = require("../models/notificationModel");
const Appointment = require("../models/appointmentModel");

const getalldoctors = async (req, res) => {
  try {
    let docs;
    if (!req.locals) {
      docs = await Doctor.find({ isDoctor: true }).populate("userId");
    } else {
      docs = await Doctor.find({ isDoctor: true })
        .find({
          _id: { $ne: req.locals },
        })
        .populate("userId");
    }

    return res.send(docs);
  } catch (error) {
    res.status(500).send("Unable to get doctors");
  }
};

const getnotdoctors = async (req, res) => {
  try {
    const docs = await Doctor.find({ isDoctor: false })
      .find({
        _id: { $ne: req.locals },
      })
      .populate("userId");

    return res.send(docs);
  } catch (error) {
    res.status(500).send("Unable to get non doctors");
  }
};

const applyfordoctor = async (req, res) => {
  try {
    console.log("Received doctor application:", req.body);
    
    const { formDetails } = req.body;
    const { specialization, experience, fees, timing } = formDetails;

    if (!specialization || !experience || !fees || !timing) {
      console.log("Missing required fields:", formDetails);
      return res.status(400).json({
        success: false,
        message: "All fields are required"
      });
    }

    const alreadyFound = await Doctor.findOne({ userId: req.locals });
    if (alreadyFound) {
      console.log("Application already exists for user:", req.locals);
      return res.status(400).json({
        success: false,
        message: "Application already exists"
      });
    }

    const doctor = new Doctor({
      ...formDetails,
      userId: req.locals,
      status: "pending"
    });

    console.log("Saving doctor application...");
    const result = await doctor.save();

    if (!result) {
      console.log("Failed to save doctor application");
      return res.status(500).json({
        success: false,
        message: "Unable to submit application"
      });
    }

    console.log("Doctor application saved successfully:", result);
    return res.status(201).json({
      success: true,
      message: "Application submitted successfully"
    });
  } catch (error) {
    console.error("Error in applyfordoctor:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to submit application",
      error: error.message
    });
  }
};

const acceptdoctor = async (req, res) => {
  try {
    const user = await User.findOneAndUpdate(
      { _id: req.body.id },
      { isDoctor: true, status: "accepted" }
    );

    const doctor = await Doctor.findOneAndUpdate(
      { userId: req.body.id },
      { isDoctor: true }
    );

    const notification = await Notification({
      userId: req.body.id,
      content: `Congratulations, Your application has been accepted.`,
    });

    await notification.save();

    return res.status(201).send("Application accepted notification sent");
  } catch (error) {
    res.status(500).send("Error while sending notification");
  }
};

const rejectdoctor = async (req, res) => {
  try {
    const details = await User.findOneAndUpdate(
      { _id: req.body.id },
      { isDoctor: false, status: "rejected" }
    );
    const delDoc = await Doctor.findOneAndDelete({ userId: req.body.id });

    const notification = await Notification({
      userId: req.body.id,
      content: `Sorry, Your application has been rejected.`,
    });

    await notification.save();

    return res.status(201).send("Application rejection notification sent");
  } catch (error) {
    res.status(500).send("Error while rejecting application");
  }
};

const deletedoctor = async (req, res) => {
  try {
    const result = await User.findByIdAndUpdate(req.body.userId, {
      isDoctor: false,
    });
    const removeDoc = await Doctor.findOneAndDelete({
      userId: req.body.userId,
    });
    const removeAppoint = await Appointment.findOneAndDelete({
      userId: req.body.userId,
    });
    return res.send("Doctor deleted successfully");
  } catch (error) {
    console.log("error", error);
    res.status(500).send("Unable to delete doctor");
  }
};

module.exports = {
  getalldoctors,
  getnotdoctors,
  deletedoctor,
  applyfordoctor,
  acceptdoctor,
  rejectdoctor,
};
