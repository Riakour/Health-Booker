const Contact = require("../models/contactModel");

const sendMessage = async (req, res) => {
  try {
    console.log("Received contact form submission:", req.body);
    
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
      console.log("Missing required fields:", { name, email, message });
      return res.status(400).json({
        success: false,
        message: "All fields are required"
      });
    }

    const contact = new Contact({
      name,
      email,
      message,
    });

    console.log("Saving contact message to database...");
    const result = await contact.save();
    
    if (!result) {
      console.log("Failed to save contact message");
      return res.status(500).json({
        success: false,
        message: "Unable to send message"
      });
    }

    console.log("Contact message saved successfully:", result);
    return res.status(201).json({
      success: true,
      message: "Message sent successfully"
    });
  } catch (error) {
    console.error("Error in sendMessage:", error);
    return res.status(500).json({
      success: false,
      message: "Unable to send message",
      error: error.message
    });
  }
};

module.exports = {
  sendMessage,
}; 