import React from "react";
import "../styles/footer.css";
import { FaFacebookF, FaYoutube, FaInstagram, FaLinkedinIn } from "react-icons/fa";
import { NavLink } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section">
          <h3>HealthBooker</h3>
          <p>Your trusted platform for healthcare professionals.</p>
        </div>

        <div className="footer-section">
          <h3>Quick Links</h3>
          <ul>
            <li><NavLink to="/">Home</NavLink></li>
            <li><NavLink to="/doctors">Doctors</NavLink></li>
            <li><NavLink to="/appointments">Appointments</NavLink></li>
            <li><NavLink to="/profile">Profile</NavLink></li>
          </ul>
        </div>

        <div className="footer-section">
          <h3>Connect</h3>
          <div className="social-icons">
            <a href="https://www.facebook.com/" target="_blank" rel="noreferrer" className="social-icon facebook">
              <FaFacebookF />
            </a>
            <a href="https://www.youtube.com/" target="_blank" rel="noreferrer" className="social-icon youtube">
              <FaYoutube />
            </a>
            <a href="https://www.instagram.com/" target="_blank" rel="noreferrer" className="social-icon instagram">
              <FaInstagram />
            </a>
            <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" className="social-icon linkedin">
              <FaLinkedinIn />
            </a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="footer-bottom-content">
          <p>&copy; {new Date().getFullYear()} HealthBooker</p>
          <div className="footer-bottom-links">
            <a href="/privacy">Privacy</a>
            <a href="/terms">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
