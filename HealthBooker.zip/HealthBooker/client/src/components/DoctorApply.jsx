import React, { useState } from "react";
import toast from "react-hot-toast";
import "../styles/doctorapply.css";
import axios from "axios";

axios.defaults.baseURL = "http://localhost:5000";

function DoctorApply() {
  const [formDetails, setFormDetails] = useState({
    specialization: "",
    experience: "",
    fees: "",
    timing: "Timing",
  });

  const inputChange = (e) => {
    const { name, value } = e.target;
    return setFormDetails({
      ...formDetails,
      [name]: value,
    });
  };

  const formSubmit = async (e) => {
    try {
      e.preventDefault();
      const { specialization, experience, fees, timing } = formDetails;

      if (!specialization || !experience || !fees || timing === "Timing") {
        return toast.error("All fields are required");
      }

      if (isNaN(experience) || experience < 0) {
        return toast.error("Experience must be a positive number");
      }

      if (isNaN(fees) || fees < 0) {
        return toast.error("Fees must be a positive number");
      }

      console.log("Submitting doctor application:", formDetails);
      
      const response = await axios.post(
        "/api/doctor/applyfordoctor",
        {
          formDetails,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      console.log("Application response:", response.data);
      
      if (response.data.success) {
        toast.success(response.data.message || "Application submitted successfully");
        setFormDetails({
          specialization: "",
          experience: "",
          fees: "",
          timing: "Timing",
        });
      } else {
        toast.error(response.data.message || "Failed to submit application");
      }
    } catch (error) {
      console.error("Error submitting application:", error.response?.data || error);
      toast.error(error.response?.data?.message || "Failed to submit application");
    }
  };

  return (
    <section className="apply-doctor-section flex-center">
      <div className="apply-doctor-container flex-center">
        <h2 className="form-heading">Apply For Doctor</h2>
        <form onSubmit={formSubmit} className="register-form">
          <input
            type="text"
            name="specialization"
            className="form-input"
            placeholder="Enter your specialization"
            value={formDetails.specialization}
            onChange={inputChange}
            required
          />
          <input
            type="number"
            name="experience"
            className="form-input"
            placeholder="Enter your experience in years"
            value={formDetails.experience}
            onChange={inputChange}
            required
            min="0"
          />
          <input
            type="number"
            name="fees"
            className="form-input"
            placeholder="Enter your fees per consultation in rupees"
            value={formDetails.fees}
            onChange={inputChange}
            required
            min="0"
          />
          <select
            name="timing"
            value={formDetails.timing}
            className="form-input"
            id="timing"
            onChange={inputChange}
            required
          >
            <option value="Timing" disabled>Select Timing</option>
            <option value="morning">Morning</option>
            <option value="afternoon">Afternoon</option>
            <option value="evening">Evening</option>
            <option value="night">Night</option>
          </select>
          <button type="submit" className="btn form-btn">
            Apply
          </button>
        </form>
      </div>
    </section>
  );
}

export default DoctorApply;
