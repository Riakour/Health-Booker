import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "../styles/notification.css";
import Empty from "../components/Empty";
import Footer from "../components/Footer";
import Navbar from "../components/Navbar";
import fetchData from "../helper/apiCall";
import { setLoading } from "../redux/reducers/rootSlice";
import Loading from "../components/Loading";
import "../styles/user.css";
import { toast } from "react-hot-toast";
import jwt_decode from "jwt-decode";

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const dispatch = useDispatch();
  const { loading } = useSelector((state) => state.root);
  const [retryCount, setRetryCount] = useState(0);
  const maxRetries = 3;

  const getAllNotifs = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        toast.error("Please login to view notifications");
        return;
      }

      let userId;
      try {
        const decoded = jwt_decode(token);
        userId = decoded.userId;
      } catch (error) {
        console.error("Error decoding token:", error);
        toast.error("Session expired. Please login again");
        return;
      }

      dispatch(setLoading(true));
      console.log("Fetching notifications for userId:", userId);
      
      const temp = await fetchData(`/api/notification/getallnotifs?search=${userId}`);
      
      console.log("Raw notifications data:", temp);
      
      // Ensure we have an array of notifications
      const notificationsArray = Array.isArray(temp) ? temp : [temp];
      setNotifications(notificationsArray);
      setRetryCount(0); // Reset retry count on success
      
      console.log("Processed notifications:", notificationsArray);
      dispatch(setLoading(false));
    } catch (error) {
      console.error("Error fetching notifications:", error);
      
      if (retryCount < maxRetries) {
        console.log(`Retrying... Attempt ${retryCount + 1} of ${maxRetries}`);
        setRetryCount(prev => prev + 1);
        setTimeout(() => {
          getAllNotifs();
        }, 1000 * (retryCount + 1)); // Exponential backoff
      } else {
        toast.error("Failed to fetch notifications. Please try again later.");
        dispatch(setLoading(false));
      }
    }
  };

  useEffect(() => {
    getAllNotifs();
  }, []);

  return (
    <>
      <Navbar />
      {loading ? (
        <Loading />
      ) : (
        <section className="container notif-section">
          <h2 className="page-heading">Your Notifications</h2>

          {notifications && notifications.length > 0 ? (
            <div className="notifications">
              <table>
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Content</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {notifications.map((ele, i) => {
                    return (
                      <tr key={ele?._id}>
                        <td>{i + 1}</td>
                        <td>{ele?.content}</td>
                        <td>{ele?.updatedAt?.split("T")[0]}</td>
                        <td>{ele?.updatedAt?.split("T")[1]?.split(".")[0]}</td>
                        <td>{ele?.isRead ? "Read" : "Unread"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <Empty />
          )}
        </section>
      )}
      <Footer />
    </>
  );
};

export default Notifications;
