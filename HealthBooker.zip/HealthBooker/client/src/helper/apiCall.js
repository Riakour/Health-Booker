import axios from "axios";

axios.defaults.baseURL = "http://localhost:5000";

const fetchData = async (url) => {
  try {
    console.log("Fetching from URL:", url);
    console.log("Token:", localStorage.getItem("token"));
    
    const { data } = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });
    
    console.log("Response data:", data);
    return data;
  } catch (error) {
    console.error("API Error:", error.response || error);
    throw error;
  }
};

export default fetchData;
