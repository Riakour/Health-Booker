const express = require("express");
const contactController = require("../controllers/contactController");

const contactRouter = express.Router();

contactRouter.post("/sendmessage", contactController.sendMessage);

module.exports = contactRouter; 